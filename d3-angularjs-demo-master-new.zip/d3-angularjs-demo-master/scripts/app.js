/* D3.js+Angular.JS Demo. Copyright (c) 2014 Uri Shaked, MIT Licence. */

'use strict';

var app = angular.module('D3Demo', []);

app.controller('MainCtrl', function ($scope, $timeout, $interval, $http) {

	$scope.jsonObj = $scope.circleData;

	$http.get('circlePacking.json').success(function (result) {
		$scope.circleData = result.hotSpots;
		$interval(updateCheckins, 250);
	});
});
