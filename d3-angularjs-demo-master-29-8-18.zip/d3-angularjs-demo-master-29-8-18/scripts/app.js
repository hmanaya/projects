/* D3.js+Angular.JS Demo. Copyright (c) 2014 Uri Shaked, MIT Licence. */

'use strict';

var app = angular.module('D3Demo', []);

app.controller('MainCtrl', function ($scope, $timeout, $interval, $compile) {
	$scope.isCountrySelected = false;
	$scope.updateGraph = function(){
		$scope.isCountrySelected = false;
		$scope.countryIn = $scope.selectedCountry;
	}
	
	$scope.applyGraph = function(){
		$scope.isCountrySelected = true;
	}
});
