/* D3.js+Angular.JS Demo. Copyright (c) 2014 Uri Shaked, MIT Licence. */

'use strict';

var app = angular.module('D3Demo', []);

app.controller('MainCtrl', function ($scope, $timeout, $interval, $http) {
	/* $scope.isDataLoaded = false;
	$scope.jsonUrl = './circlePacking.json';
	$scope.isDataLoaded = true;

	$http.get('circlePacking.json').success(function (result) {
		$scope.jsonObj = result;
		$scope.isDataLoaded = true;
	}); */
});
